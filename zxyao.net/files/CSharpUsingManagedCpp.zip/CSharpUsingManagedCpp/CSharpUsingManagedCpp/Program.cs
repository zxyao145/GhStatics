﻿using System;
using ManagedCpp;

namespace CSharpUsingManagedCpp
{
    class Program
    {
        static void Main(string[] args)
        {
            int multiple = 10;
            CppPackage cppPackage = new CppPackage(multiple);
            var calcResult = cppPackage.Calc(2);

            Console.WriteLine($"calcResult:{calcResult}");
            Console.WriteLine("Finish!");
            Console.Read();
        }
    }
}
