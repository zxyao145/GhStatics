//Test.h
#pragma once
class Test
{
private:
	int m_multiple;
public:
	Test(int multiple);
	int Calc(int value);
};

