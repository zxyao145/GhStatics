//Test.cpp
#include "stdafx.h"
#include "Test.h"
#include <iostream>

using namespace std;

Test::Test(int multiple)
{
	m_multiple = multiple;
}

int Test::Calc(int value)
{
	const int calcResult = m_multiple * value;
	cout << "c++ out:"<< calcResult <<endl;
	return calcResult;
}

